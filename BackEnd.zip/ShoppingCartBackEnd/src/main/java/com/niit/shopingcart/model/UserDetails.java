package com.niit.shopingcart.model;

public class UserDetails {

}
