package com.niit.ecart.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.niit.ecart.bean.Category;
import com.niit.ecart.dao.CategoryDAO;
@Controller
public class CategoryController 
{
	@Autowired
	CategoryDAO categoryDAO;

	@RequestMapping("/getAllCategories")
	public ModelAndView getAllCategories() {
		System.out.println("getAllCategories");
		
		List <Category> categoryList = categoryDAO.getAllCategories();  // Fetching category list from DAO 
		
		ModelAndView mv = new ModelAndView("/categoryList");   // navigating to view (to categoryList.jsp)
		mv.addObject("categoryList", categoryList);            // and adding category list to key, using this key list object can be retrieved in categoryList.jsp
		
		return mv;

	}
}
