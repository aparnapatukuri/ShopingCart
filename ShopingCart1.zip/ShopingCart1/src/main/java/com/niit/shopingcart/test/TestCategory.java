package com.niit.shopingcart.test;


import org.springframework.beans.BeansException;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TestCategory 
{

	public static void main(String[] args)
	{
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit.shopingcart.bean");
		context.refresh();
		try
		{
			context.getBean("category");
			context.getBean("product");
			
		}
		catch(BeansException e)
		{
			e.printStackTrace();
			
		}

	}

}
